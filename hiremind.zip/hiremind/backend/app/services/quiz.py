import json
from app.services.llm import generate_json
from app.models import TargetRole, QuizQuestion


def generate_questions(db, user_id: int, n: int = 10):
    target = (
        db.query(TargetRole)
        .filter_by(user_id=user_id)
        .order_by(TargetRole.id.desc())
        .first()
    )
    if target is None:
        return None

    required = json.loads(target.required_json)
    if not required:
        return []

    skills_text = ", ".join(
        f"{s.get('name', '')} (importance {s.get('importance', 3)})" for s in required
    )

    prompt = (
        f"Create {n} multiple-choice questions to test a student for the role "
        f"'{target.title}'. Required skills: {skills_text}. "
        "Ask more questions about the higher-importance skills. "
        "Each question must test practical knowledge, not trivia. "
        "Return JSON with one key 'questions', a list of objects with: "
        "skill (must be copied exactly from the skill names above), "
        "question (string), options (list of exactly 4 strings), "
        "correct_index (integer 0 to 3), explanation (one short sentence)."
    )

    data = generate_json(prompt)
    saved = []
    for q in data.get("questions", []):
        opts = q.get("options", [])
        ci = q.get("correct_index")
        if not isinstance(opts, list) or len(opts) != 4:
            continue
        if not isinstance(ci, int) or not 0 <= ci <= 3:
            continue
        row = QuizQuestion(
            user_id=user_id,
            skill=q.get("skill", ""),
            question=q.get("question", ""),
            options_json=json.dumps(opts),
            correct_index=ci,
            explanation=q.get("explanation", ""),
            answered=0,
        )
        db.add(row)
        saved.append(row)

    db.commit()
    for r in saved:
        db.refresh(r)
    return saved