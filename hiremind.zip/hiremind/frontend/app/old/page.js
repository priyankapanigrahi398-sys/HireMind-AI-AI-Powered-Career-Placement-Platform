"use client";
import { useState, useEffect } from "react";

const API = "http://127.0.0.1:8000";

async function api(path, options) {
  const res = await fetch(API + path, options);
  let data = null;
  try {
    data = await res.json();
  } catch (e) {}
  if (!res.ok) {
    const d = data && data.detail;
    throw new Error(typeof d === "string" ? d : "Request failed (" + res.status + ")");
  }
  return data;
}

function barColor(m) {
  if (m >= 0.75) return "#2e9e5b";
  if (m >= 0.4) return "#d99a1e";
  return "#d64545";
}

function Bar({ value, color }) {
  const pct = Math.round(Math.max(0, Math.min(1, value)) * 100);
  return (
    <div className="track">
      <div className="fill" style={{ width: pct + "%", background: color || barColor(value) }} />
    </div>
  );
}

function Err({ text }) {
  return text ? <p className="error">{text}</p> : null;
}

function Setup({ userId, setUserId }) {
  const [name, setName] = useState("");
  const [existing, setExisting] = useState("");
  const [jd, setJd] = useState("");
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  async function run(label, fn) {
    setBusy(label);
    setErr("");
    setMsg("");
    try {
      await fn();
    } catch (e) {
      setErr(e.message);
    }
    setBusy("");
  }

  const createUser = () =>
    run("profile", async () => {
      if (!name.trim()) throw new Error("Enter your name first.");
      const u = await api("/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim() }),
      });
      setUserId(u.id);
      setMsg("Profile created. Your id is " + u.id + ".");
    });

  const useExisting = () => {
    const n = parseInt(existing, 10);
    if (!n) {
      setErr("Enter a valid profile id.");
      return;
    }
    setErr("");
    setUserId(n);
    setMsg("Using profile " + n + ".");
  };

  const uploadResume = (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    run("resume", async () => {
      if (!userId) throw new Error("Create a profile first.");
      const fd = new FormData();
      fd.append("file", file);
      const r = await api("/users/" + userId + "/resume", { method: "POST", body: fd });
      setMsg("Resume read. Skills found: " + r.skills_added.join(", "));
    });
  };

  const saveTarget = () =>
    run("target", async () => {
      if (!userId) throw new Error("Create a profile first.");
      if (jd.trim().length < 20) throw new Error("Paste a full job description.");
      const fd = new FormData();
      fd.append("jd_text", jd);
      const r = await api("/users/" + userId + "/target", { method: "POST", body: fd });
      setMsg("Target role saved: " + r.role_title + ". Open the Dashboard tab.");
    });

  return (
    <div>
      <div className="card">
        <h3>1. Your profile</h3>
        <p className="muted">Current profile id: {userId ? userId : "none yet"}</p>
        <div className="row">
          <input placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
          <button className="btn" onClick={createUser}>Create profile</button>
        </div>
        <div className="row">
          <input placeholder="Or enter an existing profile id" value={existing} onChange={(e) => setExisting(e.target.value)} />
          <button className="btn ghost" onClick={useExisting}>Use it</button>
        </div>
      </div>

      <div className="card">
        <h3>2. Upload your resume (PDF)</h3>
        <input type="file" accept="application/pdf" onChange={uploadResume} />
      </div>

      <div className="card">
        <h3>3. Paste the job description</h3>
        <textarea rows={7} placeholder="Paste the job description here" value={jd} onChange={(e) => setJd(e.target.value)} />
        <button className="btn" onClick={saveTarget}>Save target role</button>
      </div>

      {busy && <p className="muted">Working on your {busy}. This can take a few seconds.</p>}
      {msg && <p className="ok">{msg}</p>}
      <Err text={err} />
    </div>
  );
}

function Dashboard({ userId }) {
  const [gaps, setGaps] = useState(null);
  const [skills, setSkills] = useState([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const s = await api("/users/" + userId + "/skills");
        if (!cancelled) setSkills(s);
        const g = await api("/users/" + userId + "/gaps");
        if (!cancelled) setGaps(g);
      } catch (e) {
        if (!cancelled) setErr(e.message);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [userId]);

  return (
    <div>
      <Err text={err} />
      {gaps && (
        <div className="card">
          <p className="muted">Target role</p>
          <h3>{gaps.role}</h3>
          <div className="metric">{gaps.readiness_percentage}%</div>
          <p className="muted">Placement readiness</p>
          <Bar value={gaps.readiness_percentage / 100} />
        </div>
      )}
      {gaps && (
        <div className="card">
          <h3>Skill gaps for this role</h3>
          {gaps.gaps.map((g) => (
            <div key={g.skill} className="item">
              <div className="between">
                <span>{g.skill}</span>
                <span className="muted">
                  mastery {Math.round(g.mastery * 100)}% | importance {g.importance}/5
                </span>
              </div>
              <Bar value={g.mastery} />
            </div>
          ))}
        </div>
      )}
      <div className="card">
        <h3>All your skills</h3>
        {skills.length === 0 && <p className="muted">No skills yet. Upload a resume in Setup.</p>}
        {skills.slice(0, 15).map((s) => (
          <div key={s.skill} className="item">
            <div className="between">
              <span>{s.skill}</span>
              <span className="muted">{Math.round(s.mastery * 100)}%</span>
            </div>
            <Bar value={s.mastery} />
          </div>
        ))}
      </div>
    </div>
  );
}

function Quiz({ userId }) {
  const [questions, setQuestions] = useState([]);
  const [choices, setChoices] = useState({});
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function generate() {
    setBusy(true);
    setErr("");
    setResult(null);
    setChoices({});
    try {
      setQuestions(await api("/users/" + userId + "/quiz/generate?n=10", { method: "POST" }));
    } catch (e) {
      setErr(e.message);
    }
    setBusy(false);
  }

  async function submit() {
    const answers = Object.keys(choices).map((id) => ({
      question_id: parseInt(id, 10),
      choice: choices[id],
    }));
    if (answers.length === 0) {
      setErr("Answer at least one question first.");
      return;
    }
    setBusy(true);
    setErr("");
    try {
      const r = await api("/users/" + userId + "/quiz/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers }),
      });
      setResult(r);
      setQuestions([]);
    } catch (e) {
      setErr(e.message);
    }
    setBusy(false);
  }

  return (
    <div>
      <div className="card">
        <h3>Diagnostic quiz</h3>
        <p className="muted">Questions are written for your target role. Your answers update your skill scores.</p>
        <button className="btn" onClick={generate}>Generate new quiz</button>
        {busy && <p className="muted">Working. This can take a few seconds.</p>}
        <Err text={err} />
      </div>

      {questions.map((q, n) => (
        <div key={q.question_id} className="card">
          <p className="muted">Question {n + 1} | {q.skill}</p>
          <p>{q.question}</p>
          {q.options.map((opt, i) => (
            <label key={i} className="opt">
              <input
                type="radio"
                name={"q" + q.question_id}
                checked={choices[q.question_id] === i}
                onChange={() => setChoices({ ...choices, [q.question_id]: i })}
              />{" "}
              {opt}
            </label>
          ))}
        </div>
      ))}
      {questions.length > 0 && (
        <button className="btn" onClick={submit}>Submit answers</button>
      )}

      {result && (
        <div className="card">
          <h3>Score: {result.score}</h3>
          {result.updated_gaps && (
            <p className="muted">Readiness is now {result.updated_gaps.readiness_percentage}%.</p>
          )}
          {result.results.map((r) => (
            <div key={r.question_id} className="item">
              <p className={r.correct ? "ok" : "error"}>
                {r.skill}: {r.correct ? "Correct" : "Wrong"}
              </p>
              {!r.correct && <p className="muted">Right answer: {r.right_answer}</p>}
              <p className="muted">{r.explanation}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Interview({ userId }) {
  const [kind, setKind] = useState("technical");
  const [skill, setSkill] = useState("");
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [results, setResults] = useState({});
  const [busy, setBusy] = useState("");
  const [err, setErr] = useState("");

  async function start() {
    setBusy("start");
    setErr("");
    setAnswers({});
    setResults({});
    try {
      let path = "/users/" + userId + "/interview/start?kind=" + kind + "&n=3";
      if (kind === "technical" && skill.trim()) path += "&skill=" + encodeURIComponent(skill.trim());
      setQuestions(await api(path, { method: "POST" }));
    } catch (e) {
      setErr(e.message);
    }
    setBusy("");
  }

  async function sendAnswer(q) {
    const text = (answers[q.question_id] || "").trim();
    if (text.length < 10) {
      setErr("Write a longer answer first (at least a few sentences).");
      return;
    }
    setBusy(String(q.question_id));
    setErr("");
    try {
      const r = await api("/users/" + userId + "/interview/answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question_id: q.question_id, answer: text }),
      });
      setResults({ ...results, [q.question_id]: r });
    } catch (e) {
      setErr(e.message);
    }
    setBusy("");
  }

  return (
    <div>
      <div className="card">
        <h3>Mock interview</h3>
        <div className="row">
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="technical">Technical</option>
            <option value="hr">HR (behavioral)</option>
          </select>
          {kind === "technical" && (
            <input placeholder="Focus on one skill (optional)" value={skill} onChange={(e) => setSkill(e.target.value)} />
          )}
          <button className="btn" onClick={start}>Start interview</button>
        </div>
        {busy === "start" && <p className="muted">Preparing questions.</p>}
        <Err text={err} />
      </div>

      {questions.map((q, n) => {
        const r = results[q.question_id];
        return (
          <div key={q.question_id} className="card">
            <p className="muted">Question {n + 1} | {q.skill}</p>
            <p>{q.question}</p>
            {!r && (
              <div>
                <textarea
                  rows={5}
                  placeholder="Write your answer in your own words"
                  value={answers[q.question_id] || ""}
                  onChange={(e) => setAnswers({ ...answers, [q.question_id]: e.target.value })}
                />
                <button className="btn" onClick={() => sendAnswer(q)}>Get feedback</button>
                {busy === String(q.question_id) && <p className="muted">Grading your answer.</p>}
              </div>
            )}
            {r && (
              <div>
                <div className="metric small">{r.overall_out_of_100}/100</div>
                {Object.keys(r.scores).map((k) => (
                  <div key={k} className="item">
                    <div className="between">
                      <span>{k}</span>
                      <span className="muted">{r.scores[k]}/5</span>
                    </div>
                    <Bar value={r.scores[k] / 5} />
                  </div>
                ))}
                <p>{r.feedback}</p>
                <ul>
                  {r.tips.map((t, i) => (
                    <li key={i} className="muted">{t}</li>
                  ))}
                </ul>
                {r.skill_mastery_now !== null && (
                  <p className="muted">
                    {r.skill} mastery is now {Math.round(r.skill_mastery_now * 100)}%.
                  </p>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function Roadmap({ userId }) {
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState("");

  async function load() {
    setBusy(true);
    setErr("");
    try {
      setData(await api("/users/" + userId + "/roadmap"));
    } catch (e) {
      setErr(e.message);
    }
    setBusy(false);
  }

  useEffect(() => {
    load();
  }, [userId]);

  async function complete(id) {
    setErr("");
    try {
      await api("/users/" + userId + "/roadmap/" + id + "/complete", { method: "POST" });
      await load();
    } catch (e) {
      setErr(e.message);
    }
  }

  const label = {
    learn: "Learn",
    practice_quiz: "Practice quiz",
    mock_interview: "Mock interview",
  };

  return (
    <div>
      <div className="card">
        <h3>Your adaptive roadmap</h3>
        <p className="muted">The plan re-orders itself as your quiz and interview scores change.</p>
        <button className="btn ghost" onClick={load}>Refresh</button>
        {busy && <p className="muted">Building your plan. This can take a few seconds.</p>}
        <Err text={err} />
      </div>

      {data && (
        <p className="muted">
          {data.role} | readiness {data.readiness_percentage}% | tasks completed {data.tasks_completed}
        </p>
      )}

      {data && data.plan.length === 0 && (
        <div className="card">
          <p>No open tasks. Every skill for this role is at 75% or above.</p>
        </div>
      )}

      {data &&
        data.plan.map((t) => (
          <div key={t.item_id} className="card">
            <div className="between">
              <span className="tag">{label[t.task_type]}</span>
              <span className="muted">#{t.rank} | mastery {Math.round(t.current_mastery * 100)}%</span>
            </div>
            <h3>{t.title}</h3>
            {t.details.steps && (
              <ol>
                {t.details.steps.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ol>
            )}
            {t.details.practice && <p className="muted">Practice: {t.details.practice}</p>}
            {t.details.how && <p className="muted">{t.details.how}</p>}
            {t.task_type === "learn" ? (
              <button className="btn" onClick={() => complete(t.item_id)}>Mark as done</button>
            ) : (
              <p className="muted">
                Open the {t.task_type === "practice_quiz" ? "Quiz" : "Interview"} tab to raise this score.
              </p>
            )}
          </div>
        ))}
    </div>
  );
}

export default function Home() {
  const [tab, setTab] = useState("setup");
  const [userId, setUserIdState] = useState(null);

  useEffect(() => {
    try {
      const v = localStorage.getItem("hiremind_user");
      if (v) setUserIdState(parseInt(v, 10));
    } catch (e) {}
  }, []);

  function setUserId(id) {
    setUserIdState(id);
    try {
      localStorage.setItem("hiremind_user", String(id));
    } catch (e) {}
  }

  const tabs = [
    ["setup", "Setup"],
    ["dashboard", "Dashboard"],
    ["quiz", "Quiz"],
    ["interview", "Interview"],
    ["roadmap", "Roadmap"],
  ];

  return (
    <div className="wrap">
      <header>
        <h1>HireMind AI</h1>
        <p className="muted">Placement prep that adapts to you.</p>
      </header>

      <nav className="tabs">
        {tabs.map(([key, name]) => (
          <button key={key} className={tab === key ? "tab active" : "tab"} onClick={() => setTab(key)}>
            {name}
          </button>
        ))}
      </nav>

      {tab === "setup" && <Setup userId={userId} setUserId={setUserId} />}
      {tab !== "setup" && !userId && (
        <div className="card">
          <p>Create a profile in the Setup tab first.</p>
        </div>
      )}
      {tab === "dashboard" && userId && <Dashboard userId={userId} />}
      {tab === "quiz" && userId && <Quiz userId={userId} />}
      {tab === "interview" && userId && <Interview userId={userId} />}
      {tab === "roadmap" && userId && <Roadmap userId={userId} />}
    </div>
  );
}