import Link from "next/link";

const FEATURES = [
  {
    title: "AI resume analyzer",
    text: "Extract your skills from your resume and see what is missing.",
    cls: "c1",
    icon: (
      <svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7z" /><path d="M14 3v5h5" /><path d="M10 13h6M10 17h6" /></svg>
    ),
  },
  {
    title: "Job matching",
    text: "Compare your skills with a job description and find your gaps.",
    cls: "c2",
    icon: (
      <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="4" /></svg>
    ),
  },
  {
    title: "AI mock interviews",
    text: "Practice technical and HR questions and get scored feedback.",
    cls: "c3",
    icon: (
      <svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z" /></svg>
    ),
  },
  {
    title: "Personalized learning plan",
    text: "A study roadmap that changes as your scores change.",
    cls: "c5",
    icon: (
      <svg viewBox="0 0 24 24"><path d="M4 5h7a2 2 0 012 2v13a2 2 0 00-2-2H4z" /><path d="M20 5h-7" /><path d="M20 5v13h-7" /></svg>
    ),
  },
  {
    title: "Progress dashboard",
    text: "Track your readiness and see how you are improving.",
    cls: "c6",
    icon: (
      <svg viewBox="0 0 24 24"><path d="M5 20V10M12 20V4M19 20v-7" /></svg>
    ),
  },
];

const FLOW = ["Resume", "Job", "Skill gap", "Learning", "Interview", "Performance", "Reassessment"];
const WAVE = [8, 14, 20, 12, 22, 16, 10, 20, 14, 8, 18, 12, 6, 15, 10];

export default function Landing() {
  return (
    <div className="lp2">
      <nav className="lp2-nav">
        <div className="lp2-logo">
          <div className="lp2-mark">H</div>
          <div>
            <div className="lp2-name">HireMind AI</div>
            <div className="lp2-tag">Your placement success partner</div>
          </div>
        </div>
        <div className="lp2-menu">
          <a href="#top">Home</a>
          <a href="#features">Features</a>
          <a href="#how">How it works</a>
        </div>
        <div className="lp2-actions">
          <Link className="b-outline" href="/login">Login</Link>
          <Link className="b-dark" href="/login">Get started &rarr;</Link>
        </div>
      </nav>

      <section className="lp3-hero" id="top">
        <div className="lp3-left">
          <span className="lp2-badge">✦ AI-Powered &middot; Personalized &middot; Placement Ready</span>
          <h1>
            Turn Your Skills Into<br />
            <span className="lp2-grad">Career Opportunities</span>
          </h1>
          <p className="lp2-lead">
            HireMind AI is your all-in-one AI placement copilot. Analyze your resume,
            match with top companies, practice interviews, improve your skills and
            get job-ready — all in one place.
          </p>
          <div className="lp2-cta">
            <Link className="b-dark big" href="/login">🚀 Start Your Journey</Link>
            <a className="b-light big" href="#how">▶ Watch Demo</a>
          </div>
          <div className="lp2-stats">
            <div className="lp2-stat"><b>👥 10,000+</b><span>Students Trust Us</span></div>
            <div className="lp2-stat"><b>🏢 500+</b><span>Hiring Companies</span></div>
            <div className="lp2-stat"><b>⭐ 4.9/5</b><span>User Rating</span></div>
          </div>
        </div>

        <div className="lp3-right">
          <div className="lp3-photo" role="img" aria-label="Student preparing for placements" />

          <div className="lp3-card f-resume">
            <div className="card-head">
              <div className="ci blue">
                <svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7z" /><path d="M14 3v5h5" /><path d="M10 13h6M10 17h6" /></svg>
              </div>
              <div>
                <div className="ch-title">Resume Analysis</div>
                <div className="ch-sub">ATS Score</div>
              </div>
            </div>
            <div className="resume-body">
              <div className="checks">
                <div><span className="dotok">&#10003;</span>Skills Detected</div>
                <div><span className="dotok">&#10003;</span>Strengths Identified</div>
                <div><span className="dotok">&#10003;</span>Improvement Suggestions</div>
              </div>
              <svg width="56" height="56" viewBox="0 0 80 80">
                <defs>
                  <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#2563eb" />
                    <stop offset="100%" stopColor="#14b8a6" />
                  </linearGradient>
                </defs>
                <circle cx="40" cy="40" r="32" fill="none" stroke="#e5e7eb" strokeWidth="9" />
                <circle cx="40" cy="40" r="32" fill="none" stroke="url(#ringGrad)" strokeWidth="9" strokeLinecap="round" strokeDasharray="173 201" transform="rotate(-90 40 40)" />
                <text x="40" y="46" textAnchor="middle" fontSize="17" fontWeight="700" fill="#111827">86%</text>
              </svg>
            </div>
          </div>

          <div className="lp3-card f-job">
            <div className="card-head">
              <div className="ci violet">
                <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="4" /></svg>
              </div>
              <div>
                <div className="ch-title">Job Matching</div>
                <div className="ch-sub">Top Company: TCS</div>
              </div>
            </div>
            <div className="bar-row">
              <div className="bar"><span style={{ width: "92%" }} /></div>
              <b className="bar-num">92% Match</b>
            </div>
            <div className="chips">
              <span className="chip amber">Java</span>
              <span className="chip ora">SQL</span>
              <span className="chip">React</span>
              <span className="chip">+2</span>
            </div>
          </div>

          <div className="lp3-card f-mock">
            <div className="card-head">
              <div className="ci sky">
                <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-6 8-6s8 2 8 6" /></svg>
              </div>
              <div>
                <div className="ch-title">Mock Interview</div>
                <div className="ch-sub">Next Question</div>
              </div>
            </div>
            <div className="mock-row">
              <div className="wave">
                {WAVE.map((h, i) => (
                  <span key={i} style={{ height: h + "px" }} />
                ))}
              </div>
              <span className="next-arrow">&rsaquo;</span>
            </div>
          </div>

          <div className="lp3-note-card">
            Your<br />Future<br />Starts<br />Here
          </div>

          <div className="lp3-books">📚</div>

          <div className="lp3-bubble">
            <span className="spark">✦</span> Practice Today,<br />Place Tomorrow
          </div>
        </div>
      </section>

      <section className="lp2-sec" id="features">
        <div className="lp2-eyebrow">OUR FEATURES</div>
        <h2>Everything you need for placement success</h2>
        <p className="lp2-sub">From resume analysis to the final interview, get AI-powered support at every step.</p>
        <div className="lp2-feats">
          {FEATURES.map((f) => (
            <div key={f.title} className="lp2-feat">
              <div className={"ico " + f.cls}>{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="lp2-sec" id="how">
        <div className="lp2-eyebrow">HOW IT WORKS</div>
        <h2>One continuous loop, not a one-time report</h2>
        <p className="lp2-sub">Every quiz, interview, and coding result updates your skill scores, and your plan re-orders itself.</p>
        <div className="lp2-steps">
          {FLOW.map((step, i) => (
            <span key={step} className="lp2-steps">
              <span className="lp2-step">{step}</span>
              {i < FLOW.length - 1 && <span className="lp2-arrow">&rarr;</span>}
            </span>
          ))}
        </div>
      </section>

      <div className="lp2-foot">HireMind AI</div>
    </div>
  );
}